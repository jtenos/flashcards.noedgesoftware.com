"use strict";

module.exports = function(userID) {
    this.userID = userID;

/*
    this.getDynamoObject = () => {
        return {
            userID: { S: this.userID }
        };
    };
    */
};
